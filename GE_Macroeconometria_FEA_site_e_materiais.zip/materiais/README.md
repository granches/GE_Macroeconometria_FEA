# Materiais do Grupo de Estudos em Macroeconometria

Arquive neste diretório os **materiais produzidos pelo grupo**, como slides, notas e exercícios.

## Organização sugerida

Dentro da pasta do ano, crie uma pasta para cada encontro no formato `AAAA-MM-DD-assunto`, por exemplo:

```
materiais/
  2026/
    2026-11-05-identification-macroeconomics/
      slides.pdf
      notas.md
    2026-11-19-weak-instruments/
      slides.pdf
      codigo.R
  2027/
```

Não é obrigatório criar subpastas se houver apenas um arquivo. Prefira nomes de arquivo sem acentos ou espaços para facilitar links.

## Como enviar arquivos

No GitHub, entre na pasta do ano (ou do encontro), escolha **Add file > Upload files**, arraste os arquivos e confirme **Commit changes**.

No navegador, GitHub aceita arquivos de até 25 MiB cada; para maiores, use GitHub Desktop ou ferramentas Git respeitando os limites do GitHub.

## Divulgação

O repositório é público. Qualquer pessoa poderá acessar os materiais enviados.

Para artigos acadêmicos publicados por terceiros, prefira compartilhar o link oficial (DOI, editora, RePEc, SSRN ou versão aberta autorizada), em vez de redistribuir PDFs sujeitos a direitos autorais.

Você pode compartilhar links diretos para os arquivos no GitHub. Para acrescentar uma seção **Materiais** ao site com links editáveis pelo Pages CMS, será necessária uma pequena adaptação adicional.
